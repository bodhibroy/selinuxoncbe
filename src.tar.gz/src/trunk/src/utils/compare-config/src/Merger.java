import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.text.AbstractDocument.BranchElement;


public class Merger {
	
	
	

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		BufferedReader br = null;
		String input = "";
		HashMap<String, Config> original= new HashMap<String, Config>();
		ArrayList<Config> origList = new ArrayList<Config>();

		//String ss = "1";
		//int i = Integer.parseInt(ss);

		if (args.length < 3 || args[0].equalsIgnoreCase("--help"))
		{
			System.out.println("Args: <Config1> <Config2> <switch (1/2/3/4)>");
			System.out.println("1 ==> Present in c2 but not present in c1");
			System.out.println("2 ==> Not set in c2 but Set in c1");
			System.out.println("3 ==> Set in c2 but not set in c1");
			System.out.println("4 ==> Set in both but different value (prints out c2's value).");
			return;
		}

		int option;
		try {
			option = Integer.parseInt(args[2]);
		} catch (Exception e) {
			System.out.println("Error argument 3");
			return;
		}
		//Read the file
		try {
			br = new BufferedReader(new FileReader(args[0]));			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		try {
			while((input = br.readLine()) != null) {
				Config c = ConfigManager.createConfig(input);
				origList.add(c);
				if (c.getType() ==  Config.Type.COMMENT){
					original.put(c.toString(),c);	
				} else {
					original.put(c.getConfigName(),c);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			br.close();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		try {
			br = new BufferedReader(new FileReader(args[1]));			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		try {
			while((input = br.readLine()) != null) {
				Config c2 = ConfigManager.createConfig(input);
				if (c2.getType() != Config.Type.COMMENT) {
					if (!original.containsKey(c2.getConfigName()) && option == 1) {
						System.out.println(c2.toString());
					} else if (original.containsKey(c2.getConfigName())){
						Config c1 = original.get(c2.getConfigName());
						if (option==2 && c2.getType() == Config.Type.NOT_SET && c1.getType() == Config.Type.SET) {
							System.out.println(c2.toString());
						} else if (option == 3 && c1.getType() == Config.Type.NOT_SET && c2.getType() == Config.Type.SET) {
							System.out.println(c2.toString());
						} else if (option==4 && c2.getType() == Config.Type.SET && c1.getType() == Config.Type.SET) {
							if (!c2.getValue().equals(c1.getValue())) {
								System.out.println(c2);
							}
						}
					}
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
