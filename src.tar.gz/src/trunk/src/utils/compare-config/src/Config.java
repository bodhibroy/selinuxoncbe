
public class Config {
	
	private String configName;
	public String getConfigName() {
		return configName;
	}


	public  enum Type {COMMENT, NOT_SET, SET};
	private String value;
	public String getValue() {
		return value;
	}


	private Type type;

	public Type getType() {
		return type;
	}


	public Config(String confName, Type type, String value) {
		this.configName = confName;
		this.type = type;
		this.value = value;
	}
	
	
	@Override
	public String toString() {
		String str = "";
		if (type == Type.COMMENT)
			return this.configName;
		
		if (type == Type.NOT_SET)
			str = "# ";
		str+=configName;
		if (type == Type.NOT_SET)
			str+=" is not set";
		else
			str=str+"="+value;
		return str;
	}
}
