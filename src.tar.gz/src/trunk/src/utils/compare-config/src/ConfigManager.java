

public class ConfigManager {

	private static String getConfigName(String input) {
		String str;
		boolean success = true;
		try {
			str = input.substring(input.indexOf("CONFIG_"));
		} catch (Exception e1) {
			return "";
		}
		try {
			str = str.substring(0, str.indexOf('='));
		} catch (Exception e) {
			success = false;
		}
		if (!success) {
			try {
				str = str.substring(0, str.indexOf(' '));
			} catch (Exception e) {
				success = false;
			}			
		}
		if (!success) {
			str = str.substring(0);
		}
		return str;
	}
	
	public static Config createConfig(String str){
		Config.Type type;
		String configName = "";
		String value = "";
		
		str = str.trim();
		
		if (str== null || str.length() == 0) {
			type = Config.Type.COMMENT;
			return new Config("",type,"");
		}
		
		configName = getConfigName(str);
		
		if (str.charAt(0) == '#') {
			if (str.indexOf("CONFIG_") == -1) {
				type = Config.Type.COMMENT;
				if (!configName.equals(""))
					System.out.println("DISCREPENCY");
				//If it is a comment then configname shld be the whole string
				configName = str;
			} else {
				type = Config.Type.NOT_SET;				
			}
		} else {
			type = Config.Type.SET;
			value = str.substring(str.indexOf('=')+1);
		}
		return new Config(configName,type,value);
	}
}
