/*
 * header.h
 *
 *  Created on: Apr 11, 2010
 *      Author: arunk
 */

#ifndef HEADER_H_
#define HEADER_H_

//This is the max len of the string
#define MAX_SIZE 32

typedef struct spu_init_transfer_data {
    unsigned long long head_addr;
    unsigned long long out_addr;
    unsigned long long input_addr;
    unsigned long long out_flag_addr;
}SPU_INITIAL_TFR;


#endif /* HEADER_H_ */
