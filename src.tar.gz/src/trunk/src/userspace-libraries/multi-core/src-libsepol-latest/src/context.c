#include <stdlib.h>
#include <string.h>
#include <errno.h>

#include <sepol/policydb/policydb.h>
#include <sepol/policydb/services.h>
#include "context_internal.h"

#include "debug.h"
#include "context.h"
#include "handle.h"
#include "mls.h"

#include <errno.h>
#include <libspe2.h>
#include <pthread.h>
#include "header.h"

/* ----- Compatibility ---- */
int policydb_context_isvalid(const policydb_t * p, const context_struct_t * c)
{

	return context_is_valid(p, c);
}
#define MAX_SPU_THREADS 	6

spe_context_ptr_t ctx[MAX_SPU_THREADS] = {0};
extern spe_program_handle_t myspu, myspu_alt;
pthread_t thread[MAX_SPU_THREADS]={0};
volatile unsigned long long *out_data[MAX_SPU_THREADS];
static char is_first = 1;

unsigned long long *input_addr[MAX_SPU_THREADS];
volatile char *out_flag[MAX_SPU_THREADS];



struct pth_context{
	int index;
	unsigned long long head;
};

spe_context_ptr_t create_and_load_context(){
	spe_context_ptr_t ctx1;
	/* Create context */
	if ((ctx1 = spe_context_create (0, NULL)) == NULL) {
		perror ("Failed creating context");
		exit (1);
	}
	/* Load program into context */
	if (spe_program_load (ctx1, &myspu)) {
		perror ("Failed loading program");
		exit (1);
	}
	return ctx1;
}

spe_context_ptr_t create_and_load_context_alt(){
	spe_context_ptr_t ctx1;
	/* Create context */
	if ((ctx1 = spe_context_create (0, NULL)) == NULL) {
		perror ("Failed creating context");
		exit (1);
	}
	/* Load program into context */
	if (spe_program_load (ctx1, &myspu_alt)) {
		perror ("Failed loading program");
		exit (1);
	}
	return ctx1;
}


int sepol_check_context(const char *context)
{

	int i;
	//This is called when we invoke 'setfiles' command with -c option
	//Now since we are going to parallelize this code, we are creating the SPE contexts here
	//Note: The SPE contexts will be destroyed later...
	if (is_first) {//reset is_first in context_from_record
#ifdef _DEBUG_
		printf("Creating SPE contexts...\n");
#endif
		for (i = 0; i < MAX_SPU_THREADS/2; ++i) {
			//create and load context
			ctx[i]=create_and_load_context();
			out_data[i] = (unsigned long long*)malloc(sizeof(unsigned long long));
			input_addr[i] = (unsigned long long*)malloc(sizeof(unsigned long long));
			out_flag[i] = (char*)malloc(sizeof(char));
			//This flag will take values 0,1,2
			// When it is 1, spe starts doing the operation and sets it to 2 on completion.
			//PPE waits till this becomes 2.
			out_flag[i][0]=0;
		}

		for (i = MAX_SPU_THREADS/2; i < MAX_SPU_THREADS; ++i) {
			//create and load context
			ctx[i]=create_and_load_context_alt();
			out_data[i] = (unsigned long long*)malloc(sizeof(unsigned long long));
			input_addr[i] = (unsigned long long*)malloc(sizeof(unsigned long long));
			out_flag[i] = (char*)malloc(sizeof(char));
			//This flag will take values 0,1,2
			// When it is 1, spe starts doing the operation and sets it to 2 on completion.
			//PPE waits till this becomes 2.
			out_flag[i][0]=0;
		}
	}

	return sepol_context_to_sid((const sepol_security_context_t)context,
			strlen(context) + 1, NULL);
}

/* ---- End compatibility --- */

/*
 * Return 1 if the fields in the security context
 * structure `c' are valid.  Return 0 otherwise.
 */
int context_is_valid(const policydb_t * p, const context_struct_t * c)
{

	role_datum_t *role;
	user_datum_t *usrdatum;
	ebitmap_t types, roles;
	int ret = 1;

	ebitmap_init(&types);
	ebitmap_init(&roles);
	if (!c->role || c->role > p->p_roles.nprim)
		return 0;

	if (!c->user || c->user > p->p_users.nprim)
		return 0;

	if (!c->type || c->type > p->p_types.nprim)
		return 0;

	if (c->role != OBJECT_R_VAL) {
		/*
		 * Role must be authorized for the type.
		 */
		role = p->role_val_to_struct[c->role - 1];
		if (!ebitmap_get_bit(&role->cache, c->type - 1))
			/* role may not be associated with type */
			return 0;

		/*
		 * User must be authorized for the role.
		 */
		usrdatum = p->user_val_to_struct[c->user - 1];
		if (!usrdatum)
			return 0;

		if (!ebitmap_get_bit(&usrdatum->cache, c->role - 1))
			/* user may not be associated with role */
			return 0;
	}

	if (!mls_context_isvalid(p, c))
		return 0;

	return ret;
}

/*
 * Write the security context string representation of
 * the context structure `context' into a dynamically
 * allocated string of the correct size.  Set `*scontext'
 * to point to this string and set `*scontext_len' to
 * the length of the string.
 */
int context_to_string(sepol_handle_t * handle,
		const policydb_t * policydb,
		const context_struct_t * context,
		char **result, size_t * result_len)
{

	char *scontext = NULL;
	size_t scontext_len = 0;
	char *ptr;

	/* Compute the size of the context. */
	scontext_len +=
			strlen(policydb->p_user_val_to_name[context->user - 1]) + 1;
	scontext_len +=
			strlen(policydb->p_role_val_to_name[context->role - 1]) + 1;
	scontext_len += strlen(policydb->p_type_val_to_name[context->type - 1]);
	scontext_len += mls_compute_context_len(policydb, context);

	/* We must null terminate the string */
	scontext_len += 1;

	/* Allocate space for the context; caller must free this space. */
	scontext = malloc(scontext_len);
	if (!scontext)
		goto omem;
	scontext[scontext_len - 1] = '\0';

	/*
	 * Copy the user name, role name and type name into the context.
	 */
	ptr = scontext;
	sprintf(ptr, "%s:%s:%s",
			policydb->p_user_val_to_name[context->user - 1],
			policydb->p_role_val_to_name[context->role - 1],
			policydb->p_type_val_to_name[context->type - 1]);

	ptr +=
			strlen(policydb->p_user_val_to_name[context->user - 1]) + 1 +
			strlen(policydb->p_role_val_to_name[context->role - 1]) + 1 +
			strlen(policydb->p_type_val_to_name[context->type - 1]);

	mls_sid_to_context(policydb, context, &ptr);

	*result = scontext;
	*result_len = scontext_len;
	return STATUS_SUCCESS;

	omem:
	ERR(handle, "out of memory, could not convert " "context to string");
	free(scontext);
	return STATUS_ERR;
}

void *ppu_pthread_function(void *arg) {
	struct pth_context *pth_arg;
	SPU_INITIAL_TFR *tfr;
	unsigned int entry = SPE_DEFAULT_ENTRY;
	int i;

	pth_arg = ((struct pth_context *)arg);

	tfr=(SPU_INITIAL_TFR*)malloc(sizeof(SPU_INITIAL_TFR));
	i=pth_arg->index;
	tfr->head_addr=pth_arg->head;
	tfr->out_addr=(unsigned long long)(out_data[i]);
	tfr->input_addr = (unsigned long long)input_addr[i%3];
	tfr->out_flag_addr = (unsigned long long)(out_flag[i]);

	if (spe_context_run(ctx[i], &entry, 0, tfr, NULL, NULL) < 0) {
		perror ("Failed running context");
		exit (1);
	}

	free(tfr);

	pthread_exit(NULL);
}

/*
 * Create a context structure from the given record
 */
int context_from_record(sepol_handle_t * handle,
		const policydb_t * policydb,
		context_struct_t ** cptr,
		const sepol_context_t * record)
{

	int i;
	context_struct_t *scontext = NULL;
	user_datum_t *usrdatum;
	role_datum_t *roldatum;
	type_datum_t *typdatum;

	struct pth_context pth_arg[MAX_SPU_THREADS];

	/* Hashtab keys are not constant - suppress warnings */
	char *user = strdup(sepol_context_get_user(record));
	char *role1 = strdup(sepol_context_get_role(record));
	char *type = strdup(sepol_context_get_type(record));
	const char *mls = sepol_context_get_mls(record);

	scontext = (context_struct_t *) malloc(sizeof(context_struct_t));
	if (!user || !role1 || !type || !scontext) {
		ERR(handle, "out of memory");
		goto err;
	}
	context_init(scontext);
#ifdef _DEBUG_
	printf("Searching for the user = %s in Linked list 1...\n",user);
#endif

	//Set up the global tfr data
	input_addr[0][0]=(unsigned long long)user;
	input_addr[1][0]=(unsigned long long)role1;
	input_addr[2][0]=(unsigned long long)type;
	if (is_first) {
		is_first = 0;

		//Initialize the data for each SPE/linked list
		pth_arg[0].index = 0;
		//Note: We know that there is only one bucket, so, no need to compute hash
		//Also this can never be null becos ther has to be atleast one user/role or type
		pth_arg[0].head = (unsigned long long)policydb->p_users.table->htable[0];

		if (pthread_create (&thread[0], NULL, &ppu_pthread_function, &pth_arg[0]))  {
			perror ("Failed creating thread");
			exit (1);
		}

		//Initialize the data for each SPE/linked list
		pth_arg[3].index = 3;
		//Note: We know that there is only one bucket, so, no need to compute hash
		//Also this can never be null becos ther has to be atleast one user/role or type
		pth_arg[3].head = (unsigned long long)policydb->p_users.table->htable[0];

		if (pthread_create (&thread[3], NULL, &ppu_pthread_function, &pth_arg[3]))  {
			perror ("Failed creating thread");
			exit (1);
		}

		//Initialize the data for each SPE/linked list
		pth_arg[1].index = 1;
		//Note: We know that there is only one bucket, so, no need to compute hash
		//Also this can never be null becos ther has to be atleast one user/role or type
		pth_arg[1].head = (unsigned long long)policydb->p_roles.table->htable[0];

		if (pthread_create (&thread[1], NULL, &ppu_pthread_function, &pth_arg[1]))  {
			perror ("Failed creating thread");
			exit (1);
		}

		//Initialize the data for each SPE/linked list
		pth_arg[4].index = 4;
		//Note: We know that there is only one bucket, so, no need to compute hash
		//Also this can never be null becos ther has to be atleast one user/role or type
		pth_arg[4].head = (unsigned long long)policydb->p_roles.table->htable[0];

		if (pthread_create (&thread[4], NULL, &ppu_pthread_function, &pth_arg[4]))  {
			perror ("Failed creating thread");
			exit (1);
		}

		//Initialize the data for each SPE/linked list
		pth_arg[2].index = 2;
		//Note: We know that there is only one bucket, so, no need to compute hash
		//Also this can never be null becos ther has to be atleast one user/role or type
		pth_arg[2].head = (unsigned long long)policydb->p_types.table->htable[0];

		if (pthread_create (&thread[2], NULL, &ppu_pthread_function, &pth_arg[2]))  {
			perror ("Failed creating thread");
			exit (1);
		}

		//Initialize the data for each SPE/linked list
		pth_arg[5].index = 5;
		//Note: We know that there is only one bucket, so, no need to compute hash
		//Also this can never be null becos ther has to be atleast one user/role or type
		pth_arg[5].head = (unsigned long long)policydb->p_types.table->htable[0];

		if (pthread_create (&thread[5], NULL, &ppu_pthread_function, &pth_arg[5]))  {
			perror ("Failed creating thread");
			exit (1);
		}

	}

	//Initialize the out data
	for (i = 0; i < MAX_SPU_THREADS; ++i) {
		out_data[i][0]=0;
		out_flag[i][0] = 1;//SPE can procees
	}
#ifdef _DEBUG_
	printf ("Waiting for SPE to complete...\n");
#endif

	//Busy Wait till the flags are set
	while(out_flag[0][0]!=2 || out_flag[3][0]!=2);

#ifdef _DEBUG_
	printf("After busy wait on out flag\n");
#endif
	usrdatum = (user_datum_t *)out_data[0][0];
	/* User */
	//We no longer use the hashtab_search for the CBE implementation
/*	usrdatum = (user_datum_t *) hashtab_search(policydb->p_users.table,
			(hashtab_key_t) user);*/
	if (!usrdatum) {
		usrdatum = (user_datum_t *)out_data[3][0];
		if (!usrdatum) {
			ERR(handle, "user %s is not defined", user);
			goto err_destroy;
		}
	}
	scontext->user = usrdatum->s.value;

#ifdef _DEBUG_
	printf ("Successfully found user = %s\n\n",user);
	printf("Searching for the role =  %s in Linked list 2...\n",role1);
#endif

	//Busy Wait till the flags are set
	while(out_flag[1][0]!=2  || out_flag[4][0]!=2);

	roldatum = (role_datum_t *)out_data[1][0];

	/* Role */
/*
	roldatum = (role_datum_t *) hashtab_search(policydb->p_roles.table,
			(hashtab_key_t) role1);
*/
	if (!roldatum) {
		roldatum = (role_datum_t *)out_data[4][0];
		if (!roldatum) {
			ERR(handle, "role %s is not defined", role1);
			goto err_destroy;
		}
	}
	scontext->role = roldatum->s.value;

#ifdef _DEBUG_
	printf ("Successfully found role = %s\n\n",role1);
	printf("Searching for the type =  %s in Linked list 3...\n",type);
#endif

	//Busy Wait till the flags are set
	while(out_flag[2][0]!=2  || out_flag[5][0]!=2);

	typdatum = (type_datum_t *)out_data[2][0];

	/* Type */
/*	typdatum = (type_datum_t *) hashtab_search(policydb->p_types.table,
			(hashtab_key_t) type);*/

	if (!typdatum || typdatum->flavor == TYPE_ATTRIB) {
		typdatum = (type_datum_t *)out_data[5][0];
		if (!typdatum || typdatum->flavor == TYPE_ATTRIB) {
			ERR(handle, "type %s is not defined", type);
			goto err_destroy;
		}
	}
	scontext->type = typdatum->s.value;

#ifdef _DEBUG_
	printf ("Successfully found type = %s\n\n",type);
#endif
	/* MLS */
	if (mls && !policydb->mls) {
		ERR(handle, "MLS is disabled, but MLS context \"%s\" found",
				mls);
		goto err_destroy;
	} else if (!mls && policydb->mls) {
		ERR(handle, "MLS is enabled, but no MLS context found");
		goto err_destroy;
	}
	if (mls && (mls_from_string(handle, policydb, mls, scontext) < 0))
		goto err_destroy;

	/* Validity check */
	if (!context_is_valid(policydb, scontext)) {
		if (mls) {
			ERR(handle,
					"invalid security context: \"%s:%s:%s:%s\"",
					user, role1, type, mls);
		} else {
			ERR(handle,
					"invalid security context: \"%s:%s:%s\"",
					user, role1, type);
		}
		goto err_destroy;
	}

	*cptr = scontext;
	free(user);
	free(type);
	free(role1);
	return STATUS_SUCCESS;

	err_destroy:
	errno = EINVAL;
	context_destroy(scontext);

	err:
	free(scontext);
	free(user);
	free(type);
	free(role1);
	ERR(handle, "could not create context structure");
	return STATUS_ERR;
}

/*
 * Create a record from the given context structure
 */
int context_to_record(sepol_handle_t * handle,
		const policydb_t * policydb,
		const context_struct_t * context,
		sepol_context_t ** record)
{

	sepol_context_t *tmp_record = NULL;
	char *mls = NULL;

	if (sepol_context_create(handle, &tmp_record) < 0)
		goto err;

	if (sepol_context_set_user(handle, tmp_record,
			policydb->p_user_val_to_name[context->user -
			                             1]) < 0)
		goto err;

	if (sepol_context_set_role(handle, tmp_record,
			policydb->p_role_val_to_name[context->role -
			                             1]) < 0)
		goto err;

	if (sepol_context_set_type(handle, tmp_record,
			policydb->p_type_val_to_name[context->type -
			                             1]) < 0)
		goto err;

	if (policydb->mls) {
		if (mls_to_string(handle, policydb, context, &mls) < 0)
			goto err;

		if (sepol_context_set_mls(handle, tmp_record, mls) < 0)
			goto err;
	}

	free(mls);
	*record = tmp_record;
	return STATUS_SUCCESS;

	err:
	ERR(handle, "could not create context record");
	sepol_context_free(tmp_record);
	free(mls);
	return STATUS_ERR;
}

/*
 * Create a context structure from the provided string.
 */
int context_from_string(sepol_handle_t * handle,
		const policydb_t * policydb,
		context_struct_t ** cptr,
		const char *con_str, size_t con_str_len)
{

	char *con_cpy = NULL;
	sepol_context_t *ctx_record = NULL;
#ifdef _DEBUG_
	printf ("\n*** Reading context: %s\n",con_str);
#endif
	/* sepol_context_from_string expects a NULL-terminated string */
	con_cpy = malloc(con_str_len + 1);
	if (!con_cpy)
		goto omem;
	memcpy(con_cpy, con_str, con_str_len);
	con_cpy[con_str_len] = '\0';

	if (sepol_context_from_string(handle, con_cpy, &ctx_record) < 0)
		goto err;
#ifdef _DEBUG_
	printf("Extracted user, role and type string from context\n\n");
#endif
	/* Now create from the data structure */
	if (context_from_record(handle, policydb, cptr, ctx_record) < 0)
		goto err;

	free(con_cpy);
	sepol_context_free(ctx_record);
	return STATUS_SUCCESS;

	omem:
	ERR(handle, "out of memory");

	err:
	ERR(handle, "could not create context structure");
	free(con_cpy);
	sepol_context_free(ctx_record);
	return STATUS_ERR;
}

int sepol_context_check(sepol_handle_t * handle,
		const sepol_policydb_t * policydb,
		const sepol_context_t * context)
{

	context_struct_t *con = NULL;
	int ret = context_from_record(handle, &policydb->p, &con, context);
	context_destroy(con);
	free(con);
	return ret;
}
