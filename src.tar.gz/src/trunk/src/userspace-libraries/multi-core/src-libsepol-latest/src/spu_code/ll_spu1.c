
#ifdef _DEBUG_
#include <stdio.h>
#endif

#include <spu_mfcio.h>
#include "../header.h"

//This is a copy of the struct in hashtab.h, bcos we dont want to insert the complete hashtab.h
//Also elems should be in the same order, we need only the long long elems
typedef struct spe_hashtab_node {
	char *key;
	unsigned long long key_addr;
	void *datum;
	unsigned long long datum_addr;
	struct spe_hashtab_node *next;
	unsigned long long next_addr;
} spe_hashtab_node_t;


spe_hashtab_node_t head;// __attribute__ ((aligned (16)));
unsigned long long head_addr, input_addr, out_addr, out_flag_addr;

int main(unsigned long long speid __attribute__ ((unused)),
		unsigned long long argp,
		unsigned long long envp __attribute__ ((unused)))
{

	char data[MAX_SIZE];
	char input[MAX_SIZE];
	unsigned long long out;
	char out_flag=0;

	SPU_INITIAL_TFR tfr;

	unsigned int tag[2];//2==> for dbl buffer
	int i,count,len_input,cur_buf,next_buf;
	unsigned long long next, key_addr;
	char flag=0;//0==> match not found

#ifdef _DEBUG_
	printf("Insid SPE (0x%llx) %d\n", speid, sizeof(tfr));
#endif

	tag[0] = mfc_tag_reserve();
	tag[1] = mfc_tag_reserve();
	if (tag[0] == MFC_TAG_INVALID || tag[1] == MFC_TAG_INVALID)
	{
		return 1;
	}

	/* DMA the control block information from system memory */
	mfc_get (&tfr, argp, sizeof(tfr), tag[0], 0, 0);

	/*   wait for the DMA to complete */
	mfc_write_tag_mask (1 << tag[0]);
	mfc_read_tag_status_all ();

	//Fetch the main data once.
	input_addr = tfr.input_addr;
	head_addr = tfr.head_addr;
	out_addr = tfr.out_addr;
	out_flag_addr = tfr.out_flag_addr;

	START:
	do{
		//Wait till the out flag is not 1
		mfc_get (&out_flag, out_flag_addr, sizeof(out_flag), tag[0], 0, 0);

		/*   wait for the DMA to complete */
		mfc_write_tag_mask (1 << tag[0]);
		mfc_read_tag_status_all ();
	}while(out_flag != 1);

	//Get the string addr from input addr
	mfc_get (&key_addr, input_addr, sizeof(key_addr), tag[0], 0, 0);
	/*   wait for the DMA to complete */
	mfc_write_tag_mask (1 << tag[0]);
	mfc_read_tag_status_all ();

	//Fetch the input string
	count=0;
#ifdef _DEBUG_
	printf("SPE KEY ADDR = %llx\n",key_addr);
#endif
	do {
		mfc_get(&input[count],key_addr,1,tag[0],0,0);
		//wait for dma, todo: use double buffering
		mfc_write_tag_mask (1 << tag[0]);
		mfc_read_tag_status_all ();

		key_addr=key_addr+1;
	}while(input[count++]!='\0');
#ifdef _DEBUG_
	printf("SPE got input string %s\n",input);
#endif

	len_input = count-1;

	next = tfr.head_addr;
	/*Double buffer is implemented by assumin that the size of the data in memory is atleast one more than
the string length*/
	do {

		/* DMA the node from system memory */
		mfc_get (&head, next, sizeof(head), tag[0], 0, 0);
		count = 0;//just to keep spu busy while dma is going on.
		flag=1;
		cur_buf=0;
		next_buf=0;
		/*   wait for the DMA to complete */
		mfc_write_tag_mask (1 << tag[0]);
		mfc_read_tag_status_all ();

		key_addr=head.key_addr;

		//First Fetch the first char
		mfc_get(&data[0],key_addr,1,tag[cur_buf],0,0);
		key_addr++;

		do {
			if(count > (len_input+1)) { //+1 because we cross the last char due to dbl buffring
				flag=0;
				break;
			}

			//Initiate the next transfer
			next_buf = cur_buf^1;

			mfc_get(&data[count+1],key_addr,1,tag[next_buf],0,0);
			//wait for dma, to finish the previous transfer
			mfc_write_tag_mask (1 << tag[cur_buf]);
			mfc_read_tag_status_all ();

			if (input[count]!=data[count]) {
				flag=0;
				cur_buf = next_buf;//To know which dma has not completed
				break;
			}
			key_addr=key_addr+1;
			cur_buf = next_buf;
		}while(data[count++] != '\0');

		//Wait for the last byte, however it is not of use to us.
		mfc_write_tag_mask (1 << tag[cur_buf]);
		mfc_read_tag_status_all ();

		if(flag==1 && len_input == (count-1))
		{
			out=head.datum_addr;
			mfc_put (&out, tfr.out_addr, 8,
					tag[cur_buf], 0, 0);

			/* wait for the DMA put to complete */
			mfc_write_tag_mask (1 << tag[cur_buf]);
			mfc_read_tag_status_all ();
#ifdef _DEBUG_
			printf("SPE:Found %s\n",input);
#endif
			break;
		}
		next = head.next_addr;
		if (next == 0) {
			break;
		}

		mfc_get (&head, next, sizeof(head), tag[cur_buf], 0, 0);

		/*   wait for the DMA to complete */
		mfc_write_tag_mask (1 << tag[cur_buf]);
		mfc_read_tag_status_all ();

		next = head.next_addr;

	} while (next != 0);

	//Set out flag to 2
	out_flag = 2;
	mfc_put (&out_flag, out_flag_addr, 4,
			tag[cur_buf], 0, 0);

	/* wait for the DMA put to complete */
	mfc_write_tag_mask (1 << tag[cur_buf]);
	mfc_read_tag_status_all ();
	goto START;

	return 1;

}
