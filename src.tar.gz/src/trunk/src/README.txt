****************************************************************************************
* This contains the steps to build the kernel with SELinux support on YDL for PS3
*
*
****************************************************************************************

How to Build:
Note: These steps have been referred from - http://www.yellowdog-board.com/viewtopic.php?f=10&t=4910&start=0

1. Set up your system so you can build RPMs using your regular user account instead of root:

Create the directories needed:

    Command: mkdir ~/rpmbuild

    Command: cd rpmbuild

    Command: mkdir BUILD  RPMS  SOURCES  SPECS  SRPMS


Create an .rpmmacros file in your home directory which points to the ~/rpmbuild directory you just created:

    Command: echo %_topdir $HOME/rpmbuild > ~/.rpmmacros

The contents of ~/.rpmmacros file should look something like this now:

    Command: %_topdir <home_dir>/rpmbuild


2. Move to your ~/rpmbuild/SRPMS directory and download the kernel src.rpm from one of the Fixstars mirrors:

    Command: cd ~/rpmbuild/SRPMS

    Download the src rpm from one of the mirrors listed here:

http://us.fixstars.com/support/downloads/
(releases/yellowdog-6.1/SRPMSkernel-2.6.27-1.ydl61.4.src.rpm)

3. Install the kernel src.rpm and take a look around at what got installed in your SOURCES and SPECS folders.

    Command: rpm -ivh kernel-2.6.27-1.ydl61.4.src.rpm


Your SOURCES folder should now contain everything used to build the YDL 6.1 kernel including the original kernel source archive, patches, Fixstars & YDL logos, kernel .config files for different architectures, and "COPYING.modules" (which appears to be some sort of debate?)

Important: Replace the file kernel-2.6.27-ppc64.config with the one available here - https://selinuxoncbe.svn.sourceforge.net/svnroot/selinuxoncbe/trunk/src/kernel-2.6.27-ppc64.config

    Command: ls ~/rpmbuild/SOURCES/

    COPYING.modules                     linux-2.6-ps3-ehci-iso.patch
    fbcon-fix-workqueue-shutdown.patch  linux-2.6-ps3-legacy-bootloader-hack.patch
    fixstars_logo_40x40.ppm             linux-2.6-ps3-storage-alias.patch
    kernel-2.6.27-ppc64.config          linux-2.6-squashfs.patch
    kernel-2.6.27-ppc64-fourk.config    linux-modules-unsupported
    kernel-2.6.27-ppc64-yhpc.config     logo_ydl_clut224.ppm
    kernel-2.6.27-ppc.config            ps3-replace-flip_ctl-by-ps3_gpu_mutex.diff
    kernel-2.6.27-ppc-yhpc.config       ps3-usb-add-shutdown-methods-2.patch
    linux-2.6.27.1.tar.bz2              ps3vram-driver.patch
    linux-2.6-build-nonintconfig.patch



Now have a look at the SPECS folder:

Command: ls ~/rpmbuild/SPECS/

    kernel.spec

Important: Replace the kernel.spec file with the one available here - https://selinuxoncbe.svn.sourceforge.net/svnroot/selinuxoncbe/trunk/src/kernel.spec


4. "Device Tree Compiler" (dtc) is one of build requirements listed in the kernel.spec file, so make sure you have that installed. You'll also need the rpmbuild command, so install that just in case:

Command:
    su -

<root password>

Command:
    yum install dtc rpm-build


Command:
    exit


5. At this point you should be able to rebuild the kernel RPM for YDL 6.1 (though there wouldn't be much point since you haven't changed anything). If you want to try rebuilding it from the kernel.spec file at this point just to confirm it works:

Command:
    cd ~/rpmbuild/SPECS


Command:
    rpmbuild -ba kernel.spec


(that's going to take a while ...)

6. Making changes ... here's where it gets fun (and I really don't know what I'm doing):

Looking back in the ~/rpmbuild/SOURCES folder, there are multiple .config files. Presumably, the one used for the Playstation 3 is "kernel-2.6.27-ppc64.config" ... so if you're using a PS3 you can edit that file and make changes. Since I know very little about this I'm not even going to bother offering any suggestions here.

Also, looking at the ~/rpmbuild/SPECS/kernel.spec file, if you're creating a modified kernel RPM you should change the release line as noted:

    # Polite request for people who spin their own kernel rpms:
    # please modify the "release" field in a way that identifies
    # that the kernel isn't the stock distribution kernel, for example by
    # adding some text to the end of the version number.
    #
    %define sublevel 27
    %define subrev 1
    %define rpmrev 4
    %define kversion 2.6.%{sublevel}
    %define kversionfull 2.6.%{sublevel}.%{subrev}
    %define rpmversion 2.6.%{sublevel}
    %if %{build_yhpc}
    %define release %{subrev}.yhpc.%{rpmrev}
    %else
    %define release %{subrev}.ydl61.%{rpmrev}
    %endif


So, if you want to bump the RPM version so it appears to be a higher version than the stock distribution kernel, you'd change:

Command:
    %define rpmrev 4


To:

Command:
    %define rpmrev 5


And to modify the "release" field in a way that identifies that the kernel isn't the stock distribution kernel you could change this:

Command:
    %define release %{subrev}.ydl61.%{rpmrev}



To something like this:

Command:
    %define release %{subrev}.ydl61.%{rpmrev}.custom



And when you finally build your new kernel RPM the name would look like this:

kernel-2.6.27-1.ydl61.5.custom.1.ppc64.rpm

If you want to add or change patches you're going to need your patch file in the ~/rpmbuild/SOURCES folder where the rest are located, and also edit the kernel.spec file so that the patches are applied. HINT: you can learn how this is done by reviewing the patches already applied in the existing spec file.

When you're done with your changes, build the kernel RPM as noted in back in Step 5.

Assuming everything goes well, you'll have new kernel RPMS in your ~/rpmbuild/RPMS/ppc64 (or ppc depending on your system architecture). Using the example above, those would be:

    kernel-2.6.27-1.ydl61.5.custom.1.ppc64.rpm
    kernel-headers-2.6.27-1.ydl61.5.custom.1.ppc64.rpm
    kernel-debuginfo-2.6.27-1.ydl61.5.custom.1.ppc64.rpm
    kernel-source-2.6.27-1.ydl61.5.custom.1.ppc64.rpm
    kernel-doc-2.6.27-1.ydl61.5.custom.1.ppc64.rpm


And also a new kernel src.rpm in your ~/rpmbuild/SRPMS folder:

    kernel-2.6.27-1.ydl61.5.custom.1.src.rpm

(this would include your modified spec file, config file, patches, etc)

To install and test your new kernel:

Command:
    cd ~/rpmbuild/RPMS/ppc64


Command:
    su -

<root password>

Command:
    rpm -ivh kernel-2.6.27-1.ydl61.5.custom.1.ppc64.rpm


Have a look at your /etc/yaboot.conf file and you should see a new entry, but it hasn't been made the default. You can reboot and press TAB at the kboot prompt to select your new kernel. If you decide you want to make it the new default you'll need to edit your /etc/yaboot.conf file, adding a default= line specifying which label / kernel you want to boot.


