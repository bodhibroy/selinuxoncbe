#! /bin/bash

#script to run test applications in the given directory
# USAGE
usage()
{
	echo
        echo USAGE:
        echo "Script to run test applications in the given directory"
        echo $0 '<'no of executables'>' '<'dest \dir'>' '<'prefix'>' '<'is_silent \(T\/F\)'>'
        echo
        exit 1
}

if [ "$1" == "--help" ]
then
usage
fi

if [ $# -lt 4 ]
then
usage
fi

echo "Starting $0..."
total_execs=$1
dest_dir=$2
prefix=$3
silent_str=0
#This flag is used to later start audit daemon
audit_stopped=0

if [ "$4" == "T" ]
then
echo "Executing tests in silent mode..."
silent_str=1
echo "Stopping audit daemon..."
#Stop audit mesages
/etc/init.d/auditd status 1>/dev/null
	if [ $? -eq 0 ]
	then
		/etc/init.d/auditd stop
		audit_stopped=1
	fi
fi

i=1
cd $dest_dir

while [ $i -le $total_execs ]
do
echo ""
echo "Executing $prefix$i"
if [ $silent_str -eq 1 ]
then
./$prefix$i 1>/dev/null
else
./$prefix$i
fi

if [ $? -eq 0 ]
then
	echo "Success"
else
	echo "FAILURE"
fi
i=`expr $i + 1`
done
echo
echo "All tests done!"
if [ $audit_stopped -eq 1 ]
then
	/etc/init.d/auditd start
fi

exit 0


