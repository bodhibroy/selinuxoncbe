#! /bin/bash

#Script to generate file_contexts
# USAGE
usage()
{
	echo
        echo USAGE:
        echo "Script to generate and insert the transition rules into the given policy file."
        echo $0 '<'no of transitions'>' '<'dest \dir full path with slash'>' '<'input file_contexts'>' '<'output file_contexts'>' '<'prefix'>'
        echo
        exit 1
}

if [ "$1" == "--help" ]
then
usage
fi

if [ $# -lt 5 ]
then
usage
fi


total_trans=$1
dest_dir=$2
ip_file=$3
op_file=$4

#This is used to generate the types eg: test1_t test1_exec_t and so on...
prefix=$5

echo "Starting $0..."

if [ -f $op_file ]
then
echo "Overwriting output file $op_file""..."
#echo "" > $op_file
fi

#First copy the contents to output file, using cat instead of cp command
echo "Copying the contents of $ip_file to $op_file file context..."
cat $ip_file > $op_file

echo "Generating security contexts and adding to $op_file"

i=1

#Append the new security contexts to the end of the file
while [ $i -le $total_trans ]
do
echo "$dest_dir$prefix$i user_u:base_r:$prefix$i""_exec_t" >> $op_file
echo "$dest_dir$prefix$i"".txt user_u:base_r:$prefix$i""_txt_t" >> $op_file

i=`expr $i + 1`
done

exit 0





