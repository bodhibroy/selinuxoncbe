#! /bin/bash

#script to compile and load the policy and to relabel the dest directory (the dir containing execs)
# USAGE
usage()
{
	echo
        echo USAGE:
        echo "Script to compile and load the policy and to relabel the dest directory (the dir containing execs)"
	echo "** Need to run as root **"
        echo $0 '<'policy.conf'>' '<'file_contexts'>' '<'full path of dest \dir'>' '<'prefix'>'
        echo
        exit 1
}

if [ "$1" == "--help" ]
then
usage
fi

if [ $# -lt 4 ]
then
usage
fi

echo "Starting $0..."
pf=$1
fc=$2
dest_dir=$3
prefix=$4

#set enforcing to permissive, not sure if this is required
echo "Setting selinux to permissive mode..."
setenforce 0

#compile the policy
echo "compiling and loading polcy $pf""..."
ver=`checkpolicy -V | awk '{print $1}'`
checkpolicy -o policy.$ver $pf

#copy to the binary policy 
cat policy.$ver > /etc/selinux/dummy/policy/policy.$ver

#copy file contexts file
cat $fc > /etc/selinux/dummy/contexts/files/file_contexts

rm -f policy.$ver

#load the policy
load_policy

echo "Re-labeing $dest_dir using $fc"
#now do the relabel
setfiles  $fc $dest_dir

#set the enforcing back
echo "Setting SElinux back to enforcing mode."
setenforce 1

exit 0



