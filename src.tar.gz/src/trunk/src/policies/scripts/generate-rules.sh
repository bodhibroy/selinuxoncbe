#! /bin/bash

#script to generate and insert the transition rules into the given policy file
# USAGE
usage()
{
	echo
        echo USAGE:
        echo "Script to generate and insert the transition rules into the given policy conf file."
        echo $0 '<'no of transitions'>' '<'input policy.conf'>' '<'output policy.conf'>' '<'prefix'>'
        echo
        exit 1
}

if [ "$1" == "--help" ]
then
usage
fi

if [ $# -lt 4 ]
then
usage
fi

#This is used to generate the types eg: test1_t test1_exec_t and so on...
prefix=$4

total_trans=$1
ip_file=$2
op_file=$3
echo "Starting $0..."
generate_trans_rules()
{
echo "Inserting the transition rules to $op_file""..."
j=1;
while [ $j -le $total_trans ]
do
echo "## ========= Start of $prefix$j""_t stuff ==============
#First create the exec type and for process and text
type $prefix$j""_exec_t;
type $prefix$j""_t;
type $prefix$j""_txt_t;
role base_r types {$prefix$j""_exec_t $prefix$j""_t $prefix$j""_txt_t};

#Following 4 rules required for domain transition
allow base_t $prefix$j""_exec_t : file {execute};
allow base_t $prefix$j""_t : process transition;
allow $prefix$j""_t $prefix$j""_exec_t : file {entrypoint};
type_transition base_t $prefix$j""_exec_t : process $prefix$j""_t;

allow base_t $prefix$j""_txt_t:file{getattr relabelto};
allow $prefix$j""_t $prefix$j""_txt_t:file {getattr read};
allow base_t $prefix$j""_exec_t: file *;

#This is reqired for relabeling
allow $prefix$j""_exec_t base_t : filesystem {associate};
allow $prefix$j""_txt_t base_t : filesystem {associate};

#This is required for the process to be created and signalled etc.
allow base_t $prefix$j""_t:process *;
allow $prefix$j""_t base_t:process *;

#This is req to be able to access libraries
allow $prefix$j""_t base_t:file *;
allow $prefix$j""_t base_t:dir *;
allow $prefix$j""_t base_t:fd *;
allow $prefix$j""_t base_t:lnk_file *;
allow $prefix$j""_t base_t:chr_file *;
allow $prefix$j""_t base_t:blk_file *;
allow $prefix$j""_t base_t:sock_file *;
allow $prefix$j""_t base_t:fifo_file *;
# %%%% =========  End of $prefix$j""_t stuff ======= %%%%" >> $op_file
j=`expr $j + 1`
done
echo "Successfully inserted the transition rules to $op_file""..."
}


if [ -f $op_file ]
then
echo "Overwriting output file $op_file""..."
echo "" > $op_file
fi

#loop through the file and look for type word
count=`wc -l $ip_file |cut -d ' ' -f1`
i=0
echo "Reading $ip_file""..."
while [ $i -lt $count ]
do
#Read each line and write it to the output file
line=`head -$i $ip_file|tail -1`

echo $line >> $op_file
#Check in each line if the string type is found
echo $line | grep "type"  1>/dev/null
if [ $? -eq 0 ]
then
#start generating the policy here
echo "#=========== The "$total_trans" generated transition rules start here ======== ###" >> $op_file
generate_trans_rules
echo "#=========== The "$total_trans" generated transition rules end here =========== ###" >> $op_file

#write the remaining contents of the file
j=`expr $count - $i`
tail -$j $ip_file >> $op_file

#set i to exit the loop
i=$count
fi

i=`expr $i + 1`
done

echo "Successfully generated the rules to $op_file"
exit 0




