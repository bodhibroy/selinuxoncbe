
Intro:
The purpose of these scripts to automate the process of creating a large number types used for type enforcement. The script uses these types to generate domain transition rules for the given number of executables. It also creates the executables, text files that they are meant to be accessed, relabels the files, loads the policy and runs the test executables.


#### You need to run these commands in order
# In case running on fedora, use the corresponding policy.conf
cp ../sample-policy/ydl/policy.conf .
cp ../sample-policy/ydl/file_contexts .

sh generate-rules.sh  2 policy.conf policy.conf.gen test
sh generate-contexts.sh 2 `pwd`/test-files/ file_contexts  file_contexts.gen test
sh generate-executables.sh 2 test-files/ test
sh load_and_relabel.sh policy.conf.gen  file_contexts.gen `pwd`/test-files test
sh run-tests.sh 2 test-files/ test F

## Or instead you could just run the following script which will inturn run all the above scripts.
### T ==> quiet mode, F==> not so quiet.

sh do_all.sh 2 `pwd`/test-files/ test T



