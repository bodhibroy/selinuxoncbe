#! /bin/bash

#script to generate executables in the given destination directory
#The executables will attempt to read the text files
# USAGE
usage()
{
	echo
        echo USAGE:
        echo "This will generate executables which will attempt to read all the text files"
        echo $0 '<'no of executables'>' '<'destination \dir'>' '<'prefix'>'
        echo
        exit 1
}

if [ "$1" == "--help" ]
then
usage
fi

if [ $# -lt 3 ]
then
usage
fi

echo "Starting $0..."
#This is used to generate the exe and text files eg: test1, test1.txt
prefix=$3

total_trans=$1
dest_dir=$2
op_file=$dest_dir/$prefix.c

echo "Setting selinux to permissive mode."
setenforce 0

echo "Target directory is "$dest_dir
mkdir -p $dest_dir

if [ -f $op_file ]
then
echo "File $op_file already exists, hence overwriting..."
echo "" > $op_file
fi


#first populate the .c file

echo "Generating the source code for the executables..."
echo "#include <stdio.h>
int main () {

FILE *fp= NULL;
int ch; int i; " >> $op_file

i=1
while [ $i -le $total_trans ]
do

echo "fp = fopen(\"$prefix$i"".txt\",\"r\");
if (fp == NULL)
{
	printf(\"ERROR: Permission denied - $prefix$i"".txt\n\");
} else {
	while ((ch = fgetc(fp))!=EOF) {
		printf(\"%c\",ch);
	}
	fclose(fp);
}" >> $op_file

i=`expr $i + 1`
done

echo "" >> $op_file
echo "return 0;}" >> $op_file

#Now start compiling the file to generate the executables
echo "Compiling the source..."
gcc -o $dest_dir/a.out $op_file
echo "Creating the text files and executables..."
#start copying the executables and create corresponding text files
i=1
while [ $i -le $total_trans ]
do
cat $dest_dir/a.out > $dest_dir/$prefix$i
chmod +x $dest_dir/$prefix$i

#create the text file
echo "*********************************
This is the content of $prefix$i"".txt
**********************************" > $dest_dir/$prefix$i".txt"
i=`expr $i + 1`
done

echo "Completed generating executables and text files at $dest_dir"
rm $dest_dir/a.out

echo "Setting SElinux back to enforcing mode"
setenforce 1

exit 0

