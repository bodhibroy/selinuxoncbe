
#! /bin/bash

#script to run all the scripts one by one, starting from generating context to run tests
# USAGE
usage()
{
	echo
        echo USAGE:
        echo "script to run all the scripts one by one, starting from generate-contexts to run-tests"
	echo "** Need to run as root **"
        echo $0 '<'no of executables'>' '<'destination \dir full path with slash'>' '<'prefix'>' '<'is_silent \(T\/F\)'>'
        echo
        exit 1
}

if [ "$1" == "--help" ]
then
usage
fi

if [ $# -lt 4 ]
then
usage
fi
echo "Starting $0..."
total_execs=$1
dest_dir=$2
prefix=$3
is_silent=$4

echo "Make sure to run as root."

echo "Target directory is "$dest_dir
mkdir -p $dest_dir
sh generate-rules.sh  $total_execs policy.conf policy.conf.gen $prefix
sh generate-contexts.sh $total_execs $dest_dir file_contexts  file_contexts.gen $prefix
sh generate-executables.sh $total_execs $dest_dir $prefix
sh load_and_relabel.sh policy.conf.gen  file_contexts.gen $dest_dir $prefix
#sh run-tests.sh $total_execs $dest_dir $prefix $is_silent
echo ""
echo "=========== End of script ============"
echo ""


