#! /bin/bash

#script to generate rules so that a large number of users, roles and types are created
# USAGE
usage()
{
	echo
        echo USAGE:
        echo "Script to generate large users, roles, types into the given file."
        echo $0 '<'input policy.conf'>' '<'output policy.conf'>' '<'user_prefix'>' '<'role_prefix'>' '<'type_prefix'>' '<'no_of_users'>' '<'no_of_roles'>' '<'no_of_types'>'
        echo
        exit 1
}

if [ "$1" == "--help" ]
then
usage
fi

if [ $# -lt 8 ]
then
usage
fi

#This is used to generate the types eg: test1_t test1_exec_t and so on...
ip_file=$1
op_file=$2

user_prefix=$3
role_prefix=$4
type_prefix=$5

nusers=$6
nroles=$7
ntypes=$8


echo "Starting $0..."
generate_types()
{
echo "Inserting the types to $op_file""..."
j=1;
echo "## ========= Start of $type_prefix*""_t stuff ==============">>$op_file

while [ $j -le $ntypes ]
do
echo "type $type_prefix$j""_t;" >> $op_file
j=`expr $j + 1`
done
echo "Successfully inserted $ntypes types to $op_file""..."
}


generate_roles()
{
echo "Inserting the roles to $op_file""..."
j=1;
k=1;

echo "## ========= Start of $role_prefix*""_r stuff ==============">>$op_file

while [ $j -le $nroles ]
do
k=1;
while [ $k -le $ntypes ]
do
echo "role $role_prefix$j""_r types { $type_prefix$k""_t };" >> $op_file
k=`expr $k + 1`
done
j=`expr $j + 1`
done
echo "Successfully inserted $nroles roles to $op_file""..."
}

generate_users()
{
echo "Inserting the users to $op_file""..."
j=1;
k=1;

echo "## ========= Start of $user_prefix*""_u stuff ==============">>$op_file

while [ $j -le $nusers ]
do
k=1;
while [ $k -le $nroles ]
do
echo "user $user_prefix$j""_u roles { $role_prefix$k""_r };" >> $op_file
k=`expr $k + 1`
done
j=`expr $j + 1`
done
echo "Successfully inserted $nusers users to $op_file""..."
}


if [ -f $op_file ]
then
echo "Overwriting output file $op_file""..."
echo "" > $op_file
fi

#loop through the file and look for type word
count=`wc -l $ip_file |cut -d ' ' -f1`
i=0
echo "Reading $ip_file""..."
while [ $i -lt $count ]
do
#Read each line and write it to the output file
line=`head -$i $ip_file|tail -1`

echo $line >> $op_file
#Check in each line if the string type is found
echo $line | grep "type"  1>/dev/null
if [ $? -eq 0 ]
then
#start generating the policy here
echo "#=========== The "$ntypes" types starts here ======== ###" >> $op_file
generate_types
echo "#=========== The "$ntypes" types ends here =========== ###" >> $op_file
echo "#=========== The "$nroles" roles starts here ======== ###" >> $op_file
generate_roles
echo "#=========== The "$nroles" roles ends here =========== ###" >> $op_file
i=`expr $i + 1`
## Loop till we find the user definition
while [ $i -lt $count ]
do
line=`head -$i $ip_file|tail -1`

echo $line >> $op_file
#Check in each line if the string user_u is found
echo $line | grep "user_u"  1>/dev/null
if [ $? -eq 0 ]
then
echo "#=========== The "$nusers" users starts here ======== ###" >> $op_file
generate_users
echo "#=========== The "$nusers" users ends here =========== ###" >> $op_file

#write the remaining contents of the file
j=`expr $count - $i`
tail -$j $ip_file >> $op_file

#set i to exit the loop
i=$count

fi

i=`expr $i + 1`
done

fi

i=`expr $i + 1`
done

echo "Successfully generated the rules to $op_file"
exit 0




