#! /bin/bash

#script to generate context and rules
# USAGE
usage()
{
	echo
        echo USAGE:
        echo "script to generate context and rules"
        echo $0 '<'no of \file contexts'>' '<'user_prefix'>' '<'role_prefix'>' '<'type_prefix'>' '<'no of users'>' '<'no of roles'>'  '<'no of types'>'
        echo
        exit 1
}

if [ "$1" == "--help" ]
then
usage
fi

if [ $# -lt 6 ]
then
usage
fi

nrows=$1
user_prefix=$2
role_prefix=$3
type_prefix=$4

nusers=$5
nroles=$6
ntypes=$7


sh generate-rules-setfiles.sh policy.conf policy.conf.setfiles $user_prefix $role_prefix $type_prefix $nusers $nroles $ntypes
checkpolicy -c 21 -o policy.setfiles policy.conf.setfiles
#Run the test case with worst case ie look for the context in the end of the linked list
if [ $ntypes -gt 9 ]
then
	type_no=9
else
	type_no=$ntypes
fi

sh generate-contexts-setfiles.sh $nrows /tmp/test file_contexts.setfiles $user_prefix$nusers"_u" $role_prefix$nroles"_r" $type_prefix$type_no"_t"
echo "====== Generation Done ========"
echo "Execute the following setfiles command to measure the performance"
echo "time setfiles -c policy.setfiles  file_contexts.setfiles"




