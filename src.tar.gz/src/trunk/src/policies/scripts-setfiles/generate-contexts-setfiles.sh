#! /bin/bash

#Script to generate file_contexts
# USAGE
usage()
{
	echo
        echo USAGE:
        echo "Script to generate and insert the some dummy contexts."
        echo $0 '<'no of rows \(contexts\)'>' '<'destination full path'>' '<'output file_contexts'>' '<'user_sc'>' '<'role_sc'>' '<'type_sc'>'
        echo
        exit 1
}

if [ "$1" == "--help" ]
then
usage
fi

if [ $# -lt 6 ]
then
usage
fi


total_rows=$1
dest_dir=$2
op_file=$3

#This is used to generate the types eg: test1_t test1_exec_t and so on...
user_sc=$4
role_sc=$5
type_sc=$6

echo "Starting $0..."

if [ -f $op_file ]
then
echo "Overwriting output file $op_file""..."
echo "" > $op_file
fi


echo "Generating $total_rows"" security contexts and adding to $op_file"
#Now append the new security contexts to the end of the file
i=1
while [ $i -le $total_rows ]
do
echo "$dest_dir$i.txt $user_sc:$role_sc:$type_sc" >> $op_file

i=`expr $i + 1`
done

exit 0



