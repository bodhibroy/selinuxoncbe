#include<stdio.h>
#include<stdlib.h>

#define SIDTAB_HASH_BITS 7
#define SIDTAB_HASH_BUCKETS (1 << SIDTAB_HASH_BITS)

#define DEFAULT_USER 111
#define DEFAULT_ROLE 222

struct mls_range {
	int i;
	char ch;
};

struct context {
	unsigned int user;
	unsigned int role;
	unsigned int type;
//	char *str;	/* string representation if context cannot be mapped. */
//	int len;        /* length of string in bytes */
//	struct mls_range range;
};

struct sidtab_node {
	unsigned int sid;		/* security identifier */
	struct context context;	/* security context structure */
	struct sidtab_node *next;
};

struct sidtab_node **htable;

struct sidtab_node* create_node (unsigned int val) {
	struct sidtab_node *node = (struct sidtab_node*)malloc(sizeof(struct sidtab_node));
	//For now let the type and sid be same
	node->sid = val;

	node->context.type = val;

	node->context.user = DEFAULT_USER;
	node->context.role = DEFAULT_ROLE;

	node->next = NULL;
	return node;
}

int populate_htable (struct sidtab_node **htable, int chain_len) {

	int i, count, j;
	count = 1;
	struct sidtab_node *prev, *cur;

	if (chain_len < 1)
		return -1;

	for (i = 0; i < SIDTAB_HASH_BUCKETS; ++i )
	{
		htable[i] = create_node(count++);
		prev = htable[i];
		for (j = 1; j< chain_len; ++j) {
			cur = create_node(count++);
			prev->next = cur;
			prev = cur;
		}
	}	

	return 0;
}
void print_htable(struct sidtab_node **htable) {
	int i;
	struct sidtab_node *cur;
	for (i = 0; i < SIDTAB_HASH_BUCKETS; ++i )
	{
		printf("Bucket %d: ",i+1);
		cur = htable[i];
		while(cur) {
			printf("%d->",cur->context.type);
			cur=cur->next;			
		}
		printf("\n\n");
	}
	
}

static inline int context_cmp(struct context *c1, struct context *c2)
{
/*	if (c1->len && c2->len)
		return (c1->len == c2->len && !strcmp(c1->str, c2->str));
	if (c1->len || c2->len)
		return 0;*/
	return ((c1->user == c2->user) &&
		(c1->role == c2->role) &&
		(c1->type == c2->type));
}

int search_context(struct sidtab_node **htable, struct context *context) {
	int i;
	struct sidtab_node *cur;
	for (i = 0; i < SIDTAB_HASH_BUCKETS; ++i )
	{
		cur = htable[i];
		while(cur != NULL )
		{
			if (context_cmp(&cur->context, context))
				return cur->sid;
			cur = cur->next;
		}
	}
	return 0;
}

int main () {

	int i;
	struct context context;

	//Initialize the htable
	htable = (struct sidtab_node**)malloc(sizeof(*htable) * SIDTAB_HASH_BUCKETS);
	for (i = 0; i < SIDTAB_HASH_BUCKETS; ++i) {
		htable[i]=NULL;
	}

	populate_htable(htable, 3);
//	print_htable(htable);


	//Now search for a value:
	context.user = DEFAULT_USER;
	context.role = DEFAULT_ROLE;

	context.type = 	1222;
	i = search_context(htable, &context);
	printf ("ret = %d\n",i);
	return 0;
}
