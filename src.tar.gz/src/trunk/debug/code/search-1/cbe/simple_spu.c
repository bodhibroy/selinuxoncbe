#include <stdio.h>
#include <spu_mfcio.h>

#define MAX_CH 160
char buffer[MAX_CH];

int main(unsigned long long speid __attribute__ ((unused)),
         unsigned long long argp, 
         unsigned long long envp __attribute__ ((unused)))
{
unsigned int tag;
int i;

  printf("Hello Cell (0x%llx)\n", argp);
 tag = mfc_tag_reserve();
  if (tag == MFC_TAG_INVALID)
  {
    printf ("SPU ERROR, unable to reserve tag\n");
    return 1;
  }

  /* DMA the control block information from system memory */
  mfc_get (&buffer, argp, MAX_CH, tag, 0, 0);

  /* wait for the DMA to complete */ 
  mfc_write_tag_mask (1 << tag);
  mfc_read_tag_status_all ();

  printf("got val = %c\n",buffer[MAX_CH-1]);

  return 0;
}


