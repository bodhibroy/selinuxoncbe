/*
 * ll1-ppu.c
 *
 *  Created on: Apr 11, 2010
 *      Author: root
 */

#include <stdlib.h>
#include<string.h>
#include <stdio.h>
#include <errno.h>
#include <libspe2.h>
#include <pthread.h>
#include "header.h"
#define MAX_SPU_THREADS 	6

extern spe_program_handle_t myspu, myspu_reverse;
Node *head[MAX_SPU_THREADS/2];
char *input_str;
pthread_t thread[MAX_SPU_THREADS]={0};
char dont_proceed[MAX_SPU_THREADS]={0};

volatile int *out_data[MAX_SPU_THREADS];

struct p_context{
	int index;
	spe_context_ptr_t ctx;
};

void *ppu_pthread_function(void *arg) {
	struct p_context *pth_arg;
	SPU_TFR *tfr;
	unsigned int entry = SPE_DEFAULT_ENTRY;
	int i;

	pth_arg = ((struct p_context *)arg);

	tfr=(SPU_TFR*)malloc(sizeof(SPU_TFR));
	i=pth_arg->index;
	tfr->head_addr=(unsigned long long)head[i%(MAX_SPU_THREADS/2)];
	tfr->input_addr=(unsigned long long)input_str;
	tfr->out_addr=(unsigned long long)(out_data[pth_arg->index]);

	if (dont_proceed[i]) {
		printf("Cant proceed %d\n",i);
		return;
	}
	if (spe_context_run(pth_arg->ctx, &entry, 0, tfr, NULL, NULL) < 0) {
		perror ("Failed running context");
		exit (1);
	}
	free(tfr);
	//Cancel the other thread which is searching the same ll
	printf("Thread %d complete\n",i);
	i=(i+3)%6;
	if (out_data[pth_arg->index][0]!=0){
		if(thread[i] != 0 ) {
			pthread_cancel(thread[i]);
			printf("Cancelled thread %d\n", i);
		} else {
			dont_proceed[i]=1;
		}
	}
	pthread_exit(NULL);
}

	static char temp_ch[12];
	int num_to_string(int val){
		int temp, i=0;


		while (val > 0) {
			temp = val%10;
			temp_ch[i++]='0'+temp;
			val = val / 10;
		}
		temp_ch[i]='\0';
		return i;
	}

	Node* populate_linked_list(int count, char *prefix){
		int i, len, len1;
		Node *cur, *l_head, *prev;
		char *ch;
		l_head=NULL;
		cur = NULL;
		prev=NULL;

		len = strlen(prefix);
		for (i=0;i<count;++i) {
			len1 = num_to_string(i+1);
			ch=(char*)malloc(len+len1+1);
			strcpy(ch,prefix);
			strcat(ch,temp_ch);

			cur = (Node*)malloc(sizeof(Node));
			cur->data=ch;
			cur->data_addr=(unsigned long long)cur->data;

			cur->next=NULL;
			cur->next_addr=0;

			if (prev!=NULL)
			{
				prev->next=cur;
				prev->next_addr=(unsigned long long)cur;
			}

			prev = cur;

			if (l_head == NULL)
				l_head = cur;
		}
		return l_head;
	}

	spe_context_ptr_t create_and_load_context(){
		spe_context_ptr_t ctx;
		/* Create context */
		if ((ctx = spe_context_create (0, NULL)) == NULL) {
			perror ("Failed creating context");
			exit (1);
		}
		/* Load program into context */
		if (spe_program_load (ctx, &myspu)) {
			perror ("Failed loading program");
			exit (1);
		}
		return ctx;
	}
	spe_context_ptr_t create_and_load_context_reverse(){
		spe_context_ptr_t ctx;
		/* Create context */
		if ((ctx = spe_context_create (0, NULL)) == NULL) {
			perror ("Failed creating context");
			exit (1);
		}
		/* Load program into context */
		if (spe_program_load (ctx, &myspu_reverse)) {
			perror ("Failed loading program");
			exit (1);
		}
		return ctx;
	}
#define LL_SIZE 50

	int main()
	{
		int i,count;
		spe_context_ptr_t ctx[MAX_SPU_THREADS];
		Node *cur;

		struct p_context arg_pth[MAX_SPU_THREADS];

		printf("\n");
		//Populate 3 linked lists
		head[0] = populate_linked_list(LL_SIZE,"testing");
		head[1] = populate_linked_list(LL_SIZE,"hello");
		head[2] = populate_linked_list(LL_SIZE,"string");

		for (i = 0; i < MAX_SPU_THREADS; ++i) {
			out_data[i] = (int*)malloc(sizeof(int));
			out_data[i][0]=0;
		}


		//print the linked lists
		for (i = 0; i < MAX_SPU_THREADS/2; ++i) {
			cur=head[i];
			printf("Linked list %d:\n",i+1);
			while(cur != NULL) {
				printf("%s->",cur->data);
				cur=cur->next;
			}
			printf("NULL\n\n");
		}

		printf("Creating SPE contexts\n");
		for (i = 0; i < MAX_SPU_THREADS/2; ++i) {
			//create and load context
			ctx[i]=create_and_load_context();
		}

		for (i = MAX_SPU_THREADS/2; i < MAX_SPU_THREADS; ++i) {
			//create and load context
			ctx[i]=create_and_load_context_reverse();
		}

		input_str = (char*)malloc(MAX_SIZE);
		printf("\nEnter the string to search: ");
		fgets(input_str,MAX_SIZE-2,stdin);
		//Check if the last char is carriage return, then remove it
		count = strlen(input_str);
		if (input_str[count-1]=='\n') {
			input_str[count-1]='\0';
		}

		//run the context
		/* Create thread for each SPE context */
		printf("Executing on SPEs...\n");
		for (i = 0; i < MAX_SPU_THREADS; ++i) {
			arg_pth[i].index = i;
			arg_pth[i].ctx = ctx[i];

			if (pthread_create (&thread[i], NULL, &ppu_pthread_function, &arg_pth[i]))  {
				perror ("Failed creating thread");
				exit (1);
			}
		}

		//Wait to complete
		for (i = 0; i < MAX_SPU_THREADS; ++i) {
			if (pthread_join (thread[i], NULL)) {
				perror("Failed pthread_join");
				exit (1);
			}

			if (spe_context_destroy (ctx[i]) != 0) {
				perror("Failed destroying context");
				exit (1);
			}
		}
		count=0;
		for (i = 0; i < MAX_SPU_THREADS; ++i) {
			if (out_data[i][0]==1) {
				count=1;
				printf("\nFound \"%s\" in Linked list %d\n",input_str,i%3+1);
			}
		}
		if (!count) {
			printf("\n Input \"%s\" is NOT found.\n",input_str);
		}
		printf("\n==================================================\n");
		return 0;
	}

