ppu-gcc -c ll1-ppu.c
spu-gcc -o ll1-spu ll1-spu.c
spu-gcc -o ll2-spu ll2-spu.c
ppu-embedspu myspu ll1-spu myspu.eo
ppu-embedspu myspu_reverse ll2-spu myspu_rev.eo
ppu-gcc ll1-ppu.o myspu.eo myspu_rev.eo -o myll1 -lspe2
cp myll1  /tmp/
