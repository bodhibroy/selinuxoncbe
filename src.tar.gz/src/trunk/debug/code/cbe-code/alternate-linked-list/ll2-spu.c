/*
 * ll1-spu.c
 *
 *  Created on: Apr 11, 2010
 *      Author: arun
 */

#include <stdio.h>
#include <spu_mfcio.h>
#include "header.h"

Node head ;// __attribute__ ((aligned (16)));

int main(unsigned long long speid __attribute__ ((unused)),
		unsigned long long argp,
		unsigned long long envp __attribute__ ((unused)))
{
	char data[MAX_SIZE];
	char input[MAX_SIZE];
	int out[4]={1};
	SPU_TFR tfr;

	unsigned int tag[2];//2==> for dbl buffer
	int i,count,len_input,cur_buf,next_buf;
	unsigned long long next, data_addr;
	char flag=0;//0==> not found


	printf("Insid SPE (0x%llx) %d\n", speid, sizeof(tfr));

	tag[0] = mfc_tag_reserve();
	tag[1] = mfc_tag_reserve();
	if (tag[0] == MFC_TAG_INVALID || tag[1] == MFC_TAG_INVALID)
	{
		printf ("SPU ERROR, unable to reserve tag\n");
		return 1;
	}

	/* DMA the control block information from system memory */
	mfc_get (&tfr, argp, sizeof(tfr), tag[0], 0, 0);

	/*   wait for the DMA to complete */
	mfc_write_tag_mask (1 << tag[0]);
	mfc_read_tag_status_all ();

	//Fetch the input string
	count=0;
	data_addr=tfr.input_addr;
	do {
		mfc_get(&input[count],data_addr,1,tag[0],0,0);
		//wait for dma, todo: use double buffering
		mfc_write_tag_mask (1 << tag[0]);
		mfc_read_tag_status_all ();

		data_addr=data_addr+1;
	}while(input[count++]!='\0');

	len_input = count-1;

	next = tfr.head_addr;
/*Double buffer is implemented, assumin that the size of the data in memory is atleast one more than
the string length*/
	do {

		/* DMA the node from system memory */
		mfc_get (&head, next, sizeof(head), tag[0], 0, 0);
		count = 0;//just to keep spu busy while dma is going on.
		flag=1;
		/*   wait for the DMA to complete */
		mfc_write_tag_mask (1 << tag[0]);
		mfc_read_tag_status_all ();

		//Now we need to traverse the even nodes only, so skip the current head
		next=head.next_addr;
		if (next == 0) {
			printf("end-21\n");
			return 1;
		}


		mfc_get (&head, next, sizeof(head), tag[0], 0, 0);
		cur_buf=0;
		next_buf=0;
		/*   wait for the DMA to complete */
		mfc_write_tag_mask (1 << tag[0]);
		mfc_read_tag_status_all ();

		data_addr=head.data_addr;

		//First Fetch the first char
		mfc_get(&data[0],data_addr,1,tag[cur_buf],0,0);
		data_addr++;

		do {
			if(count > (len_input+1)) { //+1 because we cross the last char due to dbl buffring
				flag=0;
				break;
			}

			//Initiate the next transfer
			next_buf = cur_buf^1;

			mfc_get(&data[count+1],data_addr,1,tag[next_buf],0,0);
			//wait for dma, to finish the previous transfer
			mfc_write_tag_mask (1 << tag[cur_buf]);
			mfc_read_tag_status_all ();

			if (input[count]!=data[count]) {
				flag=0;
				cur_buf = next_buf;//To know which dma has not completed
				break;
			}
			data_addr=data_addr+1;
			cur_buf = next_buf;
		}while(data[count++] != '\0');

		//Wait for the last byte, however it is not of use to us.
		mfc_write_tag_mask (1 << tag[cur_buf]);
		mfc_read_tag_status_all ();

		if(flag==1 && len_input == (count-1))
		{
		    mfc_put (&out[0], tfr.out_addr, 4,
		        tag[cur_buf], 0, 0);

		    /* wait for the DMA put to complete */
		    mfc_write_tag_mask (1 << tag[cur_buf]);
		    mfc_read_tag_status_all ();
		    printf("end-2\n");
			return 0;
		}

		next = head.next_addr;
	} while (next != 0);
	printf("end-2\n");
	return 1;
}
