ppu-gcc -c ll1-ppu.c
spu-gcc -o ll1-spu ll1-spu.c 
ppu-embedspu myspu ll1-spu myspu.eo
ppu-gcc ll1-ppu.o myspu.eo -o myll1 -lspe2
cp myll1  /tmp/
