/*
 * header.h
 *
 *  Created on: Apr 11, 2010
 *      Author: root
 */

#ifndef HEADER_H_
#define HEADER_H_


#define MAX_SIZE 48

typedef struct node{

    char *data;
    unsigned long long data_addr;
    struct node *next;
    unsigned long long next_addr;

}Node;

typedef struct spu_transfer_data {
    unsigned long long input_addr;
    unsigned long long head_addr;
    unsigned long long out_addr;
    unsigned int pad[2];
}SPU_TFR;


#endif /* HEADER_H_ */
