#! /bin/bash

#script to install the userspace SELinux libraries.
# USAGE
usage()
{
        echo
        echo USAGE:
        echo "Script to install the userspace SELinux libraries."
        echo "** Need to run as root **"
        echo "sh "$0
        echo
        exit 1
}
if [ "$1" == "--help" ]
then
usage
fi

echo "Installing..."
cp libselinux.so.1 libsepol.so.1 /lib64
cp setfiles /sbin/setfiles
cp checkpolicy /usr/bin/checkpolicy

echo "Creating Links..."
ln -s /lib64/libsepol.so.1 /usr/lib64/libsepol.so
ln -s /lib64/libsepol.so.1 /usr/lib64/libsepol.so.1
ln -s /lib64/libselinux.so.1 /usr/lib64/libselinux.so
ln -s /lib64/libselinux.so.1 /usr/lib64/libselinux.so.1

echo "Successfuly Installed the SELinux User space packages"

